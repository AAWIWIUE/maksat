-- Скрипт базы данных University Course Management API (SQL Server).
-- Запускать НЕ обязательно: при старте приложение само создаёт базу и тестовые данные (EnsureCreated).
-- Скрипт приложен для сдачи работы (схема + тестовые данные).

IF DB_ID(N'UniversityDb') IS NULL CREATE DATABASE UniversityDb;
GO
USE UniversityDb;
GO

CREATE TABLE Students (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Students PRIMARY KEY,
    FirstName   NVARCHAR(100) NOT NULL,
    LastName    NVARCHAR(100) NOT NULL,
    Email       NVARCHAR(200) NOT NULL,
    BirthDate   DATE          NOT NULL,
    CreatedAt   DATETIME2(7)  NOT NULL
);
CREATE UNIQUE INDEX IX_Students_Email ON Students (Email);

CREATE TABLE Teachers (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Teachers PRIMARY KEY,
    FirstName   NVARCHAR(100) NOT NULL,
    LastName    NVARCHAR(100) NOT NULL,
    Email       NVARCHAR(200) NOT NULL,
    Department  NVARCHAR(150) NOT NULL
);
CREATE UNIQUE INDEX IX_Teachers_Email ON Teachers (Email);

CREATE TABLE Courses (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Courses PRIMARY KEY,
    Name        NVARCHAR(200)  NOT NULL,
    Description NVARCHAR(1000) NULL,
    Credits     INT            NOT NULL,
    TeacherId   INT            NOT NULL,
    CreatedAt   DATETIME2(7)   NOT NULL,
    CONSTRAINT FK_Courses_Teachers_TeacherId FOREIGN KEY (TeacherId) REFERENCES Teachers (Id) ON DELETE NO ACTION
);
CREATE INDEX IX_Courses_TeacherId ON Courses (TeacherId);

CREATE TABLE Enrollments (
    Id             INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Enrollments PRIMARY KEY,
    StudentId      INT NOT NULL,
    CourseId       INT NOT NULL,
    EnrollmentDate DATETIME2(7) NOT NULL,
    Grade          DECIMAL(5,2) NULL,
    CONSTRAINT FK_Enrollments_Students_StudentId FOREIGN KEY (StudentId) REFERENCES Students (Id) ON DELETE CASCADE,
    CONSTRAINT FK_Enrollments_Courses_CourseId   FOREIGN KEY (CourseId)  REFERENCES Courses (Id)  ON DELETE NO ACTION
);
CREATE UNIQUE INDEX IX_Enrollments_StudentId_CourseId ON Enrollments (StudentId, CourseId);
CREATE INDEX IX_Enrollments_CourseId ON Enrollments (CourseId);
GO

SET IDENTITY_INSERT Teachers ON;
INSERT INTO Teachers (Id, FirstName, LastName, Email, Department) VALUES
 (1, N'Aidos',  N'Nurlanov',  N'aidos.nurlanov@satbayev.university',   N'Computer Science'),
 (2, N'Madina', N'Sarsenova', N'madina.sarsenova@satbayev.university', N'Mathematics'),
 (3, N'Erlan',  N'Kassymov',  N'erlan.kassymov@satbayev.university',   N'Software Engineering');
SET IDENTITY_INSERT Teachers OFF;

SET IDENTITY_INSERT Students ON;
INSERT INTO Students (Id, FirstName, LastName, Email, BirthDate, CreatedAt) VALUES
 (1, N'Maksat',  N'Nurgaliyev', N'maksat.nurgaliyev@student.satbayev.university', '2005-04-12', '2026-09-01'),
 (2, N'Alex',    N'Smith',    N'alex.smith@example.com',       '2004-09-23', '2026-09-01'),
 (3, N'Dana',    N'Omarova',  N'dana.omarova@example.com',     '2005-01-30', '2026-09-01'),
 (4, N'Timur',   N'Bekov',    N'timur.bekov@example.com',      '2003-11-05', '2026-09-01'),
 (5, N'Aruzhan', N'Kenzhebek',N'aruzhan.kenzhebek@example.com','2004-06-18', '2026-09-01');
SET IDENTITY_INSERT Students OFF;

SET IDENTITY_INSERT Courses ON;
INSERT INTO Courses (Id, Name, Description, Credits, TeacherId, CreatedAt) VALUES
 (1, N'Web Services Development',        N'REST API with ASP.NET Core and EF Core', 5, 3, '2026-09-01'),
 (2, N'Databases',                       N'Relational model, SQL, normalization',   4, 1, '2026-09-01'),
 (3, N'Discrete Mathematics',            N'Logic, sets, graphs, combinatorics',     3, 2, '2026-09-01'),
 (4, N'Algorithms and Data Structures',  N'Complexity, sorting, trees, graphs',     5, 1, '2026-09-01');
SET IDENTITY_INSERT Courses OFF;

SET IDENTITY_INSERT Enrollments ON;
INSERT INTO Enrollments (Id, StudentId, CourseId, EnrollmentDate, Grade) VALUES
 (1, 1, 1, '2026-09-05', 95.00),
 (2, 1, 2, '2026-09-05', NULL),
 (3, 2, 1, '2026-09-05', 88.50),
 (4, 2, 4, '2026-09-05', NULL),
 (5, 3, 3, '2026-09-05', 76.00),
 (6, 4, 1, '2026-09-05', NULL);
SET IDENTITY_INSERT Enrollments OFF;
GO
