using AutoMapper;
using UniversityApi.DTO.Courses;
using UniversityApi.DTO.Enrollments;
using UniversityApi.DTO.Students;
using UniversityApi.DTO.Teachers;
using UniversityApi.Models;

namespace UniversityApi.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Students
        CreateMap<Student, StudentDto>();
        CreateMap<StudentCreateDto, Student>();
        CreateMap<StudentUpdateDto, Student>();
        CreateMap<Student, StudentWithCoursesDto>()
            .ForMember(d => d.Courses, o => o.MapFrom(s => s.Enrollments));
        CreateMap<Enrollment, StudentCourseDto>()
            .ForMember(d => d.EnrollmentId, o => o.MapFrom(s => s.Id))
            .ForMember(d => d.CourseName, o => o.MapFrom(s => s.Course != null ? s.Course.Name : null))
            .ForMember(d => d.Credits, o => o.MapFrom(s => s.Course != null ? s.Course.Credits : 0));

        // Teachers
        CreateMap<Teacher, TeacherDto>();
        CreateMap<TeacherCreateDto, Teacher>();
        CreateMap<TeacherUpdateDto, Teacher>();

        // Courses
        CreateMap<Course, CourseDto>()
            .ForMember(d => d.TeacherName,
                o => o.MapFrom(s => s.Teacher != null ? s.Teacher.FirstName + " " + s.Teacher.LastName : null));
        CreateMap<CourseCreateDto, Course>();
        CreateMap<CourseUpdateDto, Course>();

        // Enrollments
        CreateMap<Enrollment, EnrollmentDto>()
            .ForMember(d => d.StudentName,
                o => o.MapFrom(s => s.Student != null ? s.Student.FirstName + " " + s.Student.LastName : null))
            .ForMember(d => d.CourseName, o => o.MapFrom(s => s.Course != null ? s.Course.Name : null));
        CreateMap<EnrollmentCreateDto, Enrollment>();
    }
}
