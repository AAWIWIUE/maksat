using System.ComponentModel.DataAnnotations;

namespace UniversityApi.Models;

public abstract class BaseEntity
{
    [Key]
    public int Id { get; set; }
}
