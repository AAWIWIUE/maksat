using System.ComponentModel.DataAnnotations;

namespace UniversityApi.DTO.Enrollments;

public class EnrollmentCreateDto
{
    [Range(1, int.MaxValue, ErrorMessage = "StudentId must be a positive number")]
    public int StudentId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "CourseId must be a positive number")]
    public int CourseId { get; set; }
}

public class GradeUpdateDto
{
    [Required(ErrorMessage = "Grade is required")]
    [Range(0, 100, ErrorMessage = "Grade must be between 0 and 100")]
    public decimal? Grade { get; set; }
}

public class EnrollmentDto
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public string? StudentName { get; set; }
    public int CourseId { get; set; }
    public string? CourseName { get; set; }
    public DateTime EnrollmentDate { get; set; }
    public decimal? Grade { get; set; }
}

public class EnrollmentFilterDto
{
    public int? StudentId { get; set; }
    public int? CourseId { get; set; }
}
