using System.ComponentModel.DataAnnotations;
using UniversityApi.Common;

namespace UniversityApi.DTO.Students;

public class StudentCreateDto
{
    [Required(ErrorMessage = "FirstName is required")]
    [MaxLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "LastName is required")]
    [MaxLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Email has invalid format")]
    [MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    [PastDate]
    public DateTime BirthDate { get; set; }
}

public class StudentUpdateDto : StudentCreateDto
{
}

public class StudentDto
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>Курс студента (запись + информация о курсе).</summary>
public class StudentCourseDto
{
    public int EnrollmentId { get; set; }
    public int CourseId { get; set; }
    public string? CourseName { get; set; }
    public int Credits { get; set; }
    public DateTime EnrollmentDate { get; set; }
    public decimal? Grade { get; set; }
}

public class StudentWithCoursesDto : StudentDto
{
    public List<StudentCourseDto> Courses { get; set; } = new();
}
