using Microsoft.EntityFrameworkCore;
using UniversityApi.Models;

namespace UniversityApi.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Teacher> Teachers => Set<Teacher>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();

    // Способы конфигурации в проекте:
    //  1) Conventions      - имена таблиц, FK по именам TeacherId/StudentId/CourseId
    //  2) Data Annotations - [Key], [Required], [MaxLength], [Column] в Models
    //  3) Fluent API       - этот метод (связи, индексы, delete behavior, точность decimal)
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Student>(e =>
        {
            e.HasIndex(s => s.Email).IsUnique();
        });

        modelBuilder.Entity<Teacher>(e =>
        {
            e.HasIndex(t => t.Email).IsUnique();
        });

        modelBuilder.Entity<Course>(e =>
        {
            e.HasOne(c => c.Teacher)
                .WithMany(t => t.Courses)
                .HasForeignKey(c => c.TeacherId)
                .OnDelete(DeleteBehavior.Restrict);   // нельзя удалить преподавателя с курсами
        });

        modelBuilder.Entity<Enrollment>(e =>
        {
            e.Property(x => x.Grade).HasPrecision(5, 2);

            e.HasOne(x => x.Student)
                .WithMany(s => s.Enrollments)
                .HasForeignKey(x => x.StudentId)
                .OnDelete(DeleteBehavior.Cascade);    // удаляем студента -> удаляются его записи

            e.HasOne(x => x.Course)
                .WithMany(c => c.Enrollments)
                .HasForeignKey(x => x.CourseId)
                .OnDelete(DeleteBehavior.Restrict);   // нельзя удалить курс с записями

            // Правило №3: студент не может быть записан на один курс дважды
            e.HasIndex(x => new { x.StudentId, x.CourseId }).IsUnique();
        });

        modelBuilder.Seed();
    }
}
