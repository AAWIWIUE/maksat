using Microsoft.EntityFrameworkCore;
using UniversityApi.Models;

namespace UniversityApi.Data;

public static class ModelBuilderExtensions
{
    /// <summary>Тестовые данные (создаются вместе с базой).</summary>
    public static void Seed(this ModelBuilder mb)
    {
        var created = new DateTime(2026, 9, 1);
        var enrolled = new DateTime(2026, 9, 5);

        mb.Entity<Teacher>().HasData(
            new Teacher { Id = 1, FirstName = "Aidos", LastName = "Nurlanov", Email = "aidos.nurlanov@satbayev.university", Department = "Computer Science" },
            new Teacher { Id = 2, FirstName = "Madina", LastName = "Sarsenova", Email = "madina.sarsenova@satbayev.university", Department = "Mathematics" },
            new Teacher { Id = 3, FirstName = "Erlan", LastName = "Kassymov", Email = "erlan.kassymov@satbayev.university", Department = "Software Engineering" });

        mb.Entity<Student>().HasData(
            new Student { Id = 1, FirstName = "Maksat", LastName = "Nurgaliyev", Email = "maksat.nurgaliyev@student.satbayev.university", BirthDate = new DateTime(2005, 4, 12), CreatedAt = created },
            new Student { Id = 2, FirstName = "Alex", LastName = "Smith", Email = "alex.smith@example.com", BirthDate = new DateTime(2004, 9, 23), CreatedAt = created },
            new Student { Id = 3, FirstName = "Dana", LastName = "Omarova", Email = "dana.omarova@example.com", BirthDate = new DateTime(2005, 1, 30), CreatedAt = created },
            new Student { Id = 4, FirstName = "Timur", LastName = "Bekov", Email = "timur.bekov@example.com", BirthDate = new DateTime(2003, 11, 5), CreatedAt = created },
            new Student { Id = 5, FirstName = "Aruzhan", LastName = "Kenzhebek", Email = "aruzhan.kenzhebek@example.com", BirthDate = new DateTime(2004, 6, 18), CreatedAt = created });

        mb.Entity<Course>().HasData(
            new Course { Id = 1, Name = "Web Services Development", Description = "REST API with ASP.NET Core and EF Core", Credits = 5, TeacherId = 3, CreatedAt = created },
            new Course { Id = 2, Name = "Databases", Description = "Relational model, SQL, normalization", Credits = 4, TeacherId = 1, CreatedAt = created },
            new Course { Id = 3, Name = "Discrete Mathematics", Description = "Logic, sets, graphs, combinatorics", Credits = 3, TeacherId = 2, CreatedAt = created },
            new Course { Id = 4, Name = "Algorithms and Data Structures", Description = "Complexity, sorting, trees, graphs", Credits = 5, TeacherId = 1, CreatedAt = created });

        mb.Entity<Enrollment>().HasData(
            new Enrollment { Id = 1, StudentId = 1, CourseId = 1, EnrollmentDate = enrolled, Grade = 95m },
            new Enrollment { Id = 2, StudentId = 1, CourseId = 2, EnrollmentDate = enrolled, Grade = null },
            new Enrollment { Id = 3, StudentId = 2, CourseId = 1, EnrollmentDate = enrolled, Grade = 88.5m },
            new Enrollment { Id = 4, StudentId = 2, CourseId = 4, EnrollmentDate = enrolled, Grade = null },
            new Enrollment { Id = 5, StudentId = 3, CourseId = 3, EnrollmentDate = enrolled, Grade = 76m },
            new Enrollment { Id = 6, StudentId = 4, CourseId = 1, EnrollmentDate = enrolled, Grade = null });
    }
}
