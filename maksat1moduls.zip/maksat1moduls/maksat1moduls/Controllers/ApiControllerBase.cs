using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;

namespace UniversityApi.Controllers;

[ApiController]
[Produces("application/json")]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status409Conflict)]
[ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status500InternalServerError)]
public abstract class ApiControllerBase : ControllerBase
{
    /// <summary>Превращает ReturnResult в HTTP-ответ с нужным статус-кодом.</summary>
    protected IActionResult Send<T>(ReturnResult<T> result)
    {
        result.TraceId = HttpContext.TraceIdentifier;
        return StatusCode(result.StatusCode, result);
    }
}
