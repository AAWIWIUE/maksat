using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Students;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/students")]
public class StudentsController : ApiControllerBase
{
    private readonly IStudentService _service;

    public StudentsController(IStudentService service)
    {
        _service = service;
    }

    /// <summary>Получить всех студентов.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<StudentDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll() => Send(await _service.GetAllAsync());

    /// <summary>Получить студента по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Получить студента вместе с его курсами и оценками.</summary>
    [HttpGet("{id:int}/courses")]
    [ProducesResponseType(typeof(ReturnResult<StudentWithCoursesDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetWithCourses(int id) => Send(await _service.GetWithCoursesAsync(id));

    /// <summary>Создать студента.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] StudentCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить данные студента.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, [FromBody] StudentUpdateDto dto)
        => Send(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить студента (вместе с его записями на курсы).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
