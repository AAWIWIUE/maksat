using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Enrollments;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/enrollments")]
public class EnrollmentsController : ApiControllerBase
{
    private readonly IEnrollmentService _service;

    public EnrollmentsController(IEnrollmentService service)
    {
        _service = service;
    }

    /// <summary>Получить список записей. Фильтры: studentId, courseId.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<EnrollmentDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] EnrollmentFilterDto filter)
        => Send(await _service.GetAllAsync(filter));

    /// <summary>Получить запись по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Записать студента на курс.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Enroll([FromBody] EnrollmentCreateDto dto) => Send(await _service.EnrollAsync(dto));

    /// <summary>Изменить оценку студента.</summary>
    [HttpPut("{id:int}/grade")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateGrade(int id, [FromBody] GradeUpdateDto dto)
        => Send(await _service.UpdateGradeAsync(id, dto));

    /// <summary>Удалить студента с курса (удалить запись).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
