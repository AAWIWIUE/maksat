using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Teachers;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/teachers")]
public class TeachersController : ApiControllerBase
{
    private readonly ITeacherService _service;

    public TeachersController(ITeacherService service)
    {
        _service = service;
    }

    /// <summary>Получить всех преподавателей.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<TeacherDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll() => Send(await _service.GetAllAsync());

    /// <summary>Получить преподавателя по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Создать преподавателя.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] TeacherCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить данные преподавателя.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, [FromBody] TeacherUpdateDto dto)
        => Send(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить преподавателя (нельзя, если за ним закреплены курсы).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
