using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

/// <summary>Служебный endpoint для демонстрации обработки ошибок 500 на защите.</summary>
[Route("api/diagnostics")]
public class DiagnosticsController : ApiControllerBase
{
    /// <summary>Намеренно выбрасывает исключение - клиент получит безопасный ответ 500.</summary>
    [HttpGet("error")]
    public IActionResult ThrowError()
        => throw new InvalidOperationException("Test exception for demonstrating 500 handling");
}
