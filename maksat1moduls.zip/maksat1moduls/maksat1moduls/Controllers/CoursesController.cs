using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Courses;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/courses")]
public class CoursesController : ApiControllerBase
{
    private readonly ICourseService _service;

    public CoursesController(ICourseService service)
    {
        _service = service;
    }

    /// <summary>Получить курсы. Фильтры: search, teacherId, minCredits, maxCredits.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<CourseDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] CourseFilterDto filter)
        => Send(await _service.GetAllAsync(filter));

    /// <summary>Получить курс по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetById(int id) => Send(await _service.GetByIdAsync(id));

    /// <summary>Создать курс и закрепить его за преподавателем.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CourseCreateDto dto) => Send(await _service.CreateAsync(dto));

    /// <summary>Изменить курс.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, [FromBody] CourseUpdateDto dto)
        => Send(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить курс (нельзя, если на него записаны студенты).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<bool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Delete(int id) => Send(await _service.DeleteAsync(id));
}
