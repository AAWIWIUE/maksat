using UniversityApi.Common;

namespace UniversityApi.Middleware;

/// <summary>
/// Централизованная обработка непредвиденных ошибок:
/// клиент получает безопасный ответ, подробности пишутся только в лог.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception. TraceId: {TraceId}, Request: {Method} {Path}",
                context.TraceIdentifier, context.Request.Method, context.Request.Path);

            if (context.Response.HasStarted)
                throw;

            context.Response.Clear();
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "application/json";

            var result = ReturnResult<object>.Fail(
                500, ErrorCodes.InternalServerError, "An unexpected error occurred");
            result.TraceId = context.TraceIdentifier;

            await context.Response.WriteAsJsonAsync(result);
        }
    }
}
