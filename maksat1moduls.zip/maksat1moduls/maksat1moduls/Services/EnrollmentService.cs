using AutoMapper;
using UniversityApi.Common;
using UniversityApi.DTO.Enrollments;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public class EnrollmentService : IEnrollmentService
{
    private readonly IEnrollmentRepository _enrollments;
    private readonly IStudentRepository _students;
    private readonly ICourseRepository _courses;
    private readonly IMapper _mapper;
    private readonly ILogger<EnrollmentService> _logger;

    public EnrollmentService(
        IEnrollmentRepository enrollments,
        IStudentRepository students,
        ICourseRepository courses,
        IMapper mapper,
        ILogger<EnrollmentService> logger)
    {
        _enrollments = enrollments;
        _students = students;
        _courses = courses;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<EnrollmentDto>>> GetAllAsync(EnrollmentFilterDto filter)
    {
        var enrollments = await _enrollments.GetFilteredAsync(filter.StudentId, filter.CourseId);
        return ReturnResult<List<EnrollmentDto>>.Ok(_mapper.Map<List<EnrollmentDto>>(enrollments));
    }

    public async Task<ReturnResult<EnrollmentDto>> GetByIdAsync(int id)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment is null)
            return NotFound<EnrollmentDto>(id);

        return ReturnResult<EnrollmentDto>.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<EnrollmentDto>> EnrollAsync(EnrollmentCreateDto dto)
    {
        // Правило №2: нельзя записать несуществующего студента
        if (!await _students.ExistsAsync(dto.StudentId))
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} was not found", dto.StudentId);
            return ReturnResult<EnrollmentDto>.Fail(404, ErrorCodes.StudentNotFound, "Student not found");
        }

        // Правило №1: нельзя записать студента на несуществующий курс
        if (!await _courses.ExistsAsync(dto.CourseId))
        {
            _logger.LogWarning("Enrollment failed: course {CourseId} was not found", dto.CourseId);
            return ReturnResult<EnrollmentDto>.Fail(404, ErrorCodes.CourseNotFound, "Course not found");
        }

        // Правило №3: нельзя записаться на один курс дважды
        if (await _enrollments.PairExistsAsync(dto.StudentId, dto.CourseId))
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} is already enrolled in course {CourseId}",
                dto.StudentId, dto.CourseId);
            return ReturnResult<EnrollmentDto>.Fail(409, ErrorCodes.AlreadyEnrolled,
                "Student is already enrolled in this course");
        }

        var enrollment = _mapper.Map<Enrollment>(dto);
        enrollment.EnrollmentDate = DateTime.UtcNow;

        await _enrollments.AddAsync(enrollment);
        _logger.LogInformation("Student {StudentId} enrolled in course {CourseId}. EnrollmentId: {EnrollmentId}",
            enrollment.StudentId, enrollment.CourseId, enrollment.Id);

        var created = await _enrollments.GetByIdAsync(enrollment.Id);
        return ReturnResult<EnrollmentDto>.Created(_mapper.Map<EnrollmentDto>(created));
    }

    public async Task<ReturnResult<EnrollmentDto>> UpdateGradeAsync(int id, GradeUpdateDto dto)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment is null)
            return NotFound<EnrollmentDto>(id);

        enrollment.Grade = dto.Grade;
        await _enrollments.UpdateAsync(enrollment);
        _logger.LogInformation("Grade updated. EnrollmentId: {EnrollmentId}, Grade: {Grade}", id, dto.Grade);

        return ReturnResult<EnrollmentDto>.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment is null)
            return NotFound<bool>(id);

        await _enrollments.DeleteAsync(enrollment);
        _logger.LogInformation("Enrollment deleted. Id: {EnrollmentId}", id);

        return ReturnResult<bool>.Ok(true);
    }

    private ReturnResult<T> NotFound<T>(int id)
    {
        _logger.LogWarning("Enrollment with id {EnrollmentId} was not found", id);
        return ReturnResult<T>.Fail(404, ErrorCodes.EnrollmentNotFound, "Enrollment not found");
    }
}
