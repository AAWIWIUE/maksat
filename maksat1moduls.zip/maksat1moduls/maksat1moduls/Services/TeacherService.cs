using AutoMapper;
using UniversityApi.Common;
using UniversityApi.DTO.Teachers;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public class TeacherService : ITeacherService
{
    private readonly ITeacherRepository _teachers;
    private readonly IMapper _mapper;
    private readonly ILogger<TeacherService> _logger;

    public TeacherService(ITeacherRepository teachers, IMapper mapper, ILogger<TeacherService> logger)
    {
        _teachers = teachers;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<TeacherDto>>> GetAllAsync()
    {
        var teachers = await _teachers.GetAllAsync();
        return ReturnResult<List<TeacherDto>>.Ok(_mapper.Map<List<TeacherDto>>(teachers));
    }

    public async Task<ReturnResult<TeacherDto>> GetByIdAsync(int id)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher is null)
            return NotFound<TeacherDto>(id);

        return ReturnResult<TeacherDto>.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> CreateAsync(TeacherCreateDto dto)
    {
        if (await _teachers.EmailExistsAsync(dto.Email))
        {
            _logger.LogWarning("Attempt to create teacher with duplicate email {Email}", dto.Email);
            return ReturnResult<TeacherDto>.Fail(409, ErrorCodes.EmailAlreadyExists,
                "Teacher with this email already exists");
        }

        var teacher = _mapper.Map<Teacher>(dto);
        await _teachers.AddAsync(teacher);
        _logger.LogInformation("Teacher created. Id: {TeacherId}, Email: {Email}", teacher.Id, teacher.Email);

        return ReturnResult<TeacherDto>.Created(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> UpdateAsync(int id, TeacherUpdateDto dto)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher is null)
            return NotFound<TeacherDto>(id);

        if (await _teachers.EmailExistsAsync(dto.Email, id))
        {
            _logger.LogWarning("Attempt to update teacher {TeacherId} with duplicate email {Email}", id, dto.Email);
            return ReturnResult<TeacherDto>.Fail(409, ErrorCodes.EmailAlreadyExists,
                "Another teacher with this email already exists");
        }

        _mapper.Map(dto, teacher);
        await _teachers.UpdateAsync(teacher);
        _logger.LogInformation("Teacher updated. Id: {TeacherId}", id);

        return ReturnResult<TeacherDto>.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher is null)
            return NotFound<bool>(id);

        if (await _teachers.HasCoursesAsync(id))
        {
            _logger.LogWarning("Attempt to delete teacher {TeacherId} who still has courses", id);
            return ReturnResult<bool>.Fail(409, ErrorCodes.TeacherHasCourses,
                "Teacher cannot be deleted because they have assigned courses");
        }

        await _teachers.DeleteAsync(teacher);
        _logger.LogInformation("Teacher deleted. Id: {TeacherId}", id);

        return ReturnResult<bool>.Ok(true);
    }

    private ReturnResult<T> NotFound<T>(int id)
    {
        _logger.LogWarning("Teacher with id {TeacherId} was not found", id);
        return ReturnResult<T>.Fail(404, ErrorCodes.TeacherNotFound, "Teacher not found");
    }
}
