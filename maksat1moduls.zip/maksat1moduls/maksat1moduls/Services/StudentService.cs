using AutoMapper;
using UniversityApi.Common;
using UniversityApi.DTO.Students;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public class StudentService : IStudentService
{
    private readonly IStudentRepository _students;
    private readonly IMapper _mapper;
    private readonly ILogger<StudentService> _logger;

    public StudentService(IStudentRepository students, IMapper mapper, ILogger<StudentService> logger)
    {
        _students = students;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<List<StudentDto>>> GetAllAsync()
    {
        var students = await _students.GetAllAsync();
        return ReturnResult<List<StudentDto>>.Ok(_mapper.Map<List<StudentDto>>(students));
    }

    public async Task<ReturnResult<StudentDto>> GetByIdAsync(int id)
    {
        var student = await _students.GetByIdAsync(id);
        if (student is null)
            return NotFound<StudentDto>(id);

        return ReturnResult<StudentDto>.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentWithCoursesDto>> GetWithCoursesAsync(int id)
    {
        var student = await _students.GetByIdWithCoursesAsync(id);
        if (student is null)
            return NotFound<StudentWithCoursesDto>(id);

        return ReturnResult<StudentWithCoursesDto>.Ok(_mapper.Map<StudentWithCoursesDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> CreateAsync(StudentCreateDto dto)
    {
        if (await _students.EmailExistsAsync(dto.Email))
        {
            _logger.LogWarning("Attempt to create student with duplicate email {Email}", dto.Email);
            return ReturnResult<StudentDto>.Fail(409, ErrorCodes.EmailAlreadyExists,
                "Student with this email already exists");
        }

        var student = _mapper.Map<Student>(dto);
        student.CreatedAt = DateTime.UtcNow;

        await _students.AddAsync(student);
        _logger.LogInformation("Student created. Id: {StudentId}, Email: {Email}", student.Id, student.Email);

        return ReturnResult<StudentDto>.Created(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> UpdateAsync(int id, StudentUpdateDto dto)
    {
        var student = await _students.GetByIdAsync(id);
        if (student is null)
            return NotFound<StudentDto>(id);

        if (await _students.EmailExistsAsync(dto.Email, id))
        {
            _logger.LogWarning("Attempt to update student {StudentId} with duplicate email {Email}", id, dto.Email);
            return ReturnResult<StudentDto>.Fail(409, ErrorCodes.EmailAlreadyExists,
                "Another student with this email already exists");
        }

        _mapper.Map(dto, student);
        await _students.UpdateAsync(student);
        _logger.LogInformation("Student updated. Id: {StudentId}", id);

        return ReturnResult<StudentDto>.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<bool>> DeleteAsync(int id)
    {
        var student = await _students.GetByIdAsync(id);
        if (student is null)
            return NotFound<bool>(id);

        await _students.DeleteAsync(student);
        _logger.LogInformation("Student deleted. Id: {StudentId}", id);

        return ReturnResult<bool>.Ok(true);
    }

    private ReturnResult<T> NotFound<T>(int id)
    {
        _logger.LogWarning("Student with id {StudentId} was not found", id);
        return ReturnResult<T>.Fail(404, ErrorCodes.StudentNotFound, "Student not found");
    }
}
