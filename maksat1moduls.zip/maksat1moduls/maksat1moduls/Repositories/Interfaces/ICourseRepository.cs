using UniversityApi.Models;

namespace UniversityApi.Repositories.Interfaces;

public interface ICourseRepository : IRepository<Course>
{
    Task<List<Course>> GetFilteredAsync(string? search, int? teacherId, int? minCredits, int? maxCredits);
    Task<bool> HasEnrollmentsAsync(int courseId);
}
