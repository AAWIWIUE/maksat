using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Repositories.Implementations;

public class CourseRepository : Repository<Course>, ICourseRepository
{
    public CourseRepository(ApplicationDbContext context) : base(context)
    {
    }

    public override async Task<List<Course>> GetAllAsync()
        => await GetFilteredAsync(null, null, null, null);

    public override async Task<Course?> GetByIdAsync(int id)
        => await Set.Include(c => c.Teacher).FirstOrDefaultAsync(c => c.Id == id);

    public async Task<List<Course>> GetFilteredAsync(string? search, int? teacherId, int? minCredits, int? maxCredits)
    {
        IQueryable<Course> query = Set.AsNoTracking().Include(c => c.Teacher);

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(c => c.Name.Contains(search));

        if (teacherId.HasValue)
            query = query.Where(c => c.TeacherId == teacherId.Value);

        if (minCredits.HasValue)
            query = query.Where(c => c.Credits >= minCredits.Value);

        if (maxCredits.HasValue)
            query = query.Where(c => c.Credits <= maxCredits.Value);

        return await query.OrderBy(c => c.Name).ToListAsync();
    }

    public async Task<bool> HasEnrollmentsAsync(int courseId)
        => await Context.Enrollments.AnyAsync(e => e.CourseId == courseId);
}
