using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Repositories.Implementations;

public class EnrollmentRepository : Repository<Enrollment>, IEnrollmentRepository
{
    public EnrollmentRepository(ApplicationDbContext context) : base(context)
    {
    }

    public override async Task<List<Enrollment>> GetAllAsync()
        => await GetFilteredAsync(null, null);

    public override async Task<Enrollment?> GetByIdAsync(int id)
        => await Set
            .Include(e => e.Student)
            .Include(e => e.Course)
            .FirstOrDefaultAsync(e => e.Id == id);

    public async Task<List<Enrollment>> GetFilteredAsync(int? studentId, int? courseId)
    {
        IQueryable<Enrollment> query = Set.AsNoTracking()
            .Include(e => e.Student)
            .Include(e => e.Course);

        if (studentId.HasValue)
            query = query.Where(e => e.StudentId == studentId.Value);

        if (courseId.HasValue)
            query = query.Where(e => e.CourseId == courseId.Value);

        return await query.OrderBy(e => e.Id).ToListAsync();
    }

    public async Task<bool> PairExistsAsync(int studentId, int courseId)
        => await Set.AnyAsync(e => e.StudentId == studentId && e.CourseId == courseId);
}
