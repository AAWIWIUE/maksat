using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Repositories.Implementations;

public class Repository<T> : IRepository<T> where T : BaseEntity
{
    protected readonly ApplicationDbContext Context;
    protected readonly DbSet<T> Set;

    public Repository(ApplicationDbContext context)
    {
        Context = context;
        Set = context.Set<T>();
    }

    public virtual async Task<List<T>> GetAllAsync()
        => await Set.AsNoTracking().OrderBy(e => e.Id).ToListAsync();

    public virtual async Task<T?> GetByIdAsync(int id)
        => await Set.FirstOrDefaultAsync(e => e.Id == id);

    public virtual async Task<bool> ExistsAsync(int id)
        => await Set.AnyAsync(e => e.Id == id);

    public virtual async Task<T> AddAsync(T entity)
    {
        await Set.AddAsync(entity);
        await Context.SaveChangesAsync();
        return entity;
    }

    public virtual async Task UpdateAsync(T entity)
    {
        if (Context.Entry(entity).State == EntityState.Detached)
        {
            Set.Update(entity);
        }

        await Context.SaveChangesAsync();
    }

    public virtual async Task DeleteAsync(T entity)
    {
        Set.Remove(entity);
        await Context.SaveChangesAsync();
    }
}
