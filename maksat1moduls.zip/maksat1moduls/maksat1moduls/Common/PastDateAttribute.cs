using System.ComponentModel.DataAnnotations;

namespace UniversityApi.Common;

/// <summary>Дата должна быть в диапазоне 1900-01-01 ... вчера.</summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class PastDateAttribute : ValidationAttribute
{
    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is DateTime date && (date.Year < 1900 || date.Date >= DateTime.Today))
        {
            return new ValidationResult(
                ErrorMessage ?? $"{validationContext.DisplayName} must be between 1900-01-01 and today (exclusive).");
        }

        return ValidationResult.Success;
    }
}
