using System.Text.Json.Serialization;

namespace UniversityApi.Common;

/// <summary>Единый формат ответа для всех endpoints.</summary>
public class ReturnResult<T>
{
    public int StatusCode { get; set; }
    public bool IsSuccess { get; set; }
    public T? Result { get; set; }
    public string? ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }

    /// <summary>Подробности ошибок валидации (поле -> список сообщений).</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Dictionary<string, string[]>? Errors { get; set; }

    public string? TraceId { get; set; }

    public static ReturnResult<T> Ok(T result) => new()
    {
        StatusCode = 200,
        IsSuccess = true,
        Result = result
    };

    public static ReturnResult<T> Created(T result) => new()
    {
        StatusCode = 201,
        IsSuccess = true,
        Result = result
    };

    public static ReturnResult<T> Fail(int statusCode, string errorCode, string message,
        Dictionary<string, string[]>? errors = null) => new()
    {
        StatusCode = statusCode,
        IsSuccess = false,
        Result = default,
        ErrorCode = errorCode,
        ErrorMessage = message,
        Errors = errors
    };
}
