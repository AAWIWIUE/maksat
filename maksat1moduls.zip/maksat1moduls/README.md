# University Course Management API

REST Web API на **ASP.NET Core (.NET 8)** для управления студентами, преподавателями, курсами и записями студентов на курсы.
Курс CSE5032 «Разработка веб-сервисов», Задание 1, Модуль 1-4.

## Технологии
ASP.NET Core Web API · Entity Framework Core 8 (SQL Server) · AutoMapper · Swagger / OpenAPI · ILogger

## Запуск
1. Открыть `maksat1moduls.sln` в Visual Studio 2022 (нужна нагрузка *ASP.NET and web development* и .NET 8 SDK).
2. Нажать **F5** (профиль `http` или `https`) - откроется Swagger.
3. База `UniversityDb` с тестовыми данными создаётся автоматически при первом запуске
   (SQL Server LocalDB, строка подключения в `appsettings.json`).

Swagger: <http://localhost:5080/swagger>

Скрипт БД (схема + тестовые данные): `Database/UniversityDb.sql`.

## Архитектура
```
Client
  ↓ HTTP
Controller            (только приём запроса и формирование HTTP-ответа)
  ↓
Service               (бизнес-правила, логирование, ReturnResult<T>)
  ↓
Repository            (доступ к данным)
  ↓
Entity Framework Core (ApplicationDbContext)
  ↓
SQL Server
```

## Структура проекта
```
maksat1moduls
├── Controllers      StudentsController, TeachersController, CoursesController, EnrollmentsController, DiagnosticsController
├── Models           Student, Teacher, Course, Enrollment (+ BaseEntity)
├── DTO              Students / Teachers / Courses / Enrollments
├── Data             ApplicationDbContext, тестовые данные (Seed)
├── Repositories     Interfaces / Implementations
├── Services         бизнес-логика
├── Mapping          MappingProfile (AutoMapper)
├── Middleware       ExceptionHandlingMiddleware
├── Common           ReturnResult<T>, ErrorCodes, PastDateAttribute
├── Program.cs
└── appsettings.json
```

## Endpoints
| Метод | URL | Описание |
|---|---|---|
| GET | `/api/students` | список студентов |
| GET | `/api/students/{id}` | студент по Id |
| GET | `/api/students/{id}/courses` | студент вместе с курсами и оценками |
| POST | `/api/students` | создать студента |
| PUT | `/api/students/{id}` | изменить студента |
| DELETE | `/api/students/{id}` | удалить студента |
| GET/POST/PUT/DELETE | `/api/teachers`, `/api/teachers/{id}` | CRUD преподавателей |
| GET | `/api/courses?search=&teacherId=&minCredits=&maxCredits=` | список курсов с фильтрацией |
| GET/POST/PUT/DELETE | `/api/courses`, `/api/courses/{id}` | CRUD курсов |
| GET | `/api/enrollments?studentId=&courseId=` | список записей |
| GET | `/api/enrollments/{id}` | запись по Id |
| POST | `/api/enrollments` | записать студента на курс |
| PUT | `/api/enrollments/{id}/grade` | изменить оценку |
| DELETE | `/api/enrollments/{id}` | удалить студента с курса |
| GET | `/api/diagnostics/error` | демонстрация ответа 500 |

## Единый формат ответа
```json
{ "statusCode": 200, "isSuccess": true, "result": { }, "errorCode": null, "errorMessage": null, "traceId": "..." }
```
Ошибки валидации дополнительно содержат поле `errors` (поле → список сообщений).

## HTTP-коды и бизнес-правила
| Ситуация | Код | errorCode |
|---|---|---|
| успешное получение / изменение / удаление | 200 | - |
| создание | 201 | - |
| ошибка валидации DTO | 400 | VALIDATION_ERROR |
| объект не найден | 404 | STUDENT_NOT_FOUND, TEACHER_NOT_FOUND, COURSE_NOT_FOUND, ENROLLMENT_NOT_FOUND |
| запись на несуществующий курс / студента | 404 | COURSE_NOT_FOUND / STUDENT_NOT_FOUND |
| курс с несуществующим преподавателем | 404 | TEACHER_NOT_FOUND |
| повторная запись на курс | 409 | ALREADY_ENROLLED |
| дубликат Email | 409 | EMAIL_ALREADY_EXISTS |
| удаление преподавателя с курсами / курса с записями | 409 | TEACHER_HAS_COURSES / COURSE_HAS_ENROLLMENTS |
| непредвиденная ошибка | 500 | INTERNAL_SERVER_ERROR (детали только в логе) |

## Dependency Injection - выбор lifetime
Все репозитории и сервисы зарегистрированы как **Scoped** (один экземпляр на HTTP-запрос).
`DbContext` по умолчанию Scoped и не потокобезопасен, а репозитории/сервисы зависят от него:
Singleton дал бы конфликт lifetime (captive dependency), Transient создавал бы лишние объекты и разные контексты в рамках одного запроса.

## Конфигурация EF Core
Использованы три способа: **Conventions** (имена таблиц, FK по именам свойств), **Data Annotations** (`[Key]`, `[Required]`, `[MaxLength]`, `[Column]`),
**Fluent API** (связи, delete behavior, уникальные индексы, точность `decimal`).

## Логирование
`ILogger`: `Information` - создание / изменение / удаление; `Warning` - объект не найден, конфликты и нарушение правил; `Error` - необработанные исключения.

## Сценарии для защиты (Swagger)
1. `GET /api/students` → 200 со списком.
2. `POST /api/students` → 201; затем `GET /api/students/{id}`; `PUT /api/students/{id}`.
3. `POST /api/teachers` → 201.
4. `POST /api/courses` с `teacherId` созданного преподавателя → 201.
5. `POST /api/enrollments` `{ "studentId": 1, "courseId": 3 }` → 201; тот же запрос ещё раз → **409 ALREADY_ENROLLED**.
6. `GET /api/students/1/courses` → студент с курсами.
7. `GET /api/courses?search=web&minCredits=3` → фильтрация.
8. `DELETE /api/enrollments/{id}` или `PUT /api/enrollments/{id}/grade`.
9. `GET /api/students/9999` → **404 STUDENT_NOT_FOUND**.
10. `POST /api/students` с пустым именем и Email `abc` → **400 VALIDATION_ERROR**.
11. `GET /api/diagnostics/error` → **500**, а стек вызова виден только в консоли/логе.
